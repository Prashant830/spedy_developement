# Spedy Online Stores

Online Food and Grocery Store and Delivery Platform.
